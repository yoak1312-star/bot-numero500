module.exports = {
  name: "gen",
  execute() {
    return;
  }
};
